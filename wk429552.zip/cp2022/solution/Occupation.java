package cp2022.solution;

public enum Occupation {
    FREE,
    SWITCHING,
    TWO_OCCUPYING,
    WORKING
}
