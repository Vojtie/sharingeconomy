package cp2022.solution;

public enum Action {
    SWITCH,
    ENTER
}
